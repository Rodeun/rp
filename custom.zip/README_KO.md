# custom (RP Engine 전용 정리본)

설치: 이 `custom/` 폴더를 `plugins/RPEngine/content/` 에 넣고 `/rp reload`.
폴더 이름이 네임스페이스입니다 (`/rp give custom:sl`).

## 원본 custom.zip 에서 바뀐 것
1. 루트의 `assets/` 와 `ia_overlay_*` 10개는 `resourcepack/` 와 100% 동일한 복사본이라 삭제 (파일 수 약 13,700 → 6,583).
2. 제거 (REMOVED.txt 에 전체 목록):
   - `assets/minecraft/shaders/core/*` (rendertype_text, rendertype_armor_cutout_no_cull — Java 전용 GLSL)
   - `assets/minecraft/optifine/emissive.properties` (OptiFine 전용)
   - `assets/dragonstone_guardians/textures/fire.ase` (Aseprite 작업 파일)
3. PNG 894개 전부를 표준 PNG로 재작성 (픽셀 데이터는 그대로):
   - 607개: 청크 CRC / zlib 체크섬이 깨져 있었음 (게임은 무시하지만 일반 이미지 라이브러리는 읽기 실패)
   - `char/black.png`, `_iainternal/.../smithing.png`: IEND 뒤에 붙어 있던 잉여 바이트 제거
4. `pack.yml` 이름 정리.

## 일부러 건드리지 않은 것
- `assets/littledragonset/models/26969c9d6e01d59f` : 확장자 없는 텍스트 파일(구매자 식별 스탬프로 보임). 변환기가 확장자 없는 파일에서 문제를 일으키면 이 파일을 확인해 보세요.
- `_iainternal` (ItemsAdder 전용 GUI/폰트): RP Engine만 쓰면 미사용이지만 폰트·오버레이가 참조하므로 그대로 둠.

## 부작용
- 셰이더 제거로 Java에서 ItemsAdder식 폰트 이미지 처리·레더 갑옷 코스메틱 렌더링 효과는 사라집니다.
